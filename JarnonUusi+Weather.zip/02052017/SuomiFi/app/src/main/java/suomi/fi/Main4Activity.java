package suomi.fi;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Button btnWebsite = (Button)findViewById(R.id.btnWebsite);
        Button btnGeneral = (Button)findViewById(R.id.btnGeneral);
        TextView title = (TextView)findViewById(R.id.textTitle);
        TextView textHomePage = (TextView)findViewById(R.id.textHomePage);
        TextView textInfo = (TextView)findViewById(R.id.textInfo);

        Intent intent = getIntent();


        final String[] organizationURLS  = intent.getStringArrayExtra(MainActivity.EXTRA_MESSAGE);

        title.setText(organizationURLS[0]);
        textHomePage.setText(organizationURLS[1]);
        textInfo.setText(organizationURLS[2]);

        btnWebsite.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(organizationURLS[1]));
                startActivity(intent);
            }
        });

        btnGeneral.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(organizationURLS[2]));
                startActivity(intent);
            }
        });


    }


}