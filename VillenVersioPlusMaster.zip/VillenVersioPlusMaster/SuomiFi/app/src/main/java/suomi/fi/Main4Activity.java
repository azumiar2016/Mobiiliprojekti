package suomi.fi;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import static android.content.ContentValues.TAG;

public class Main4Activity extends AppCompatActivity {

    ArrayList<Batch> arrayOfBatches = new ArrayList<>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Button btnWebsite = (Button)findViewById(R.id.btnWebsite);
        Button btnGeneral = (Button)findViewById(R.id.btnGeneral);
        TextView title = (TextView)findViewById(R.id.textTitle);
        TextView textHomePage = (TextView)findViewById(R.id.textHomePage);
        TextView textInfo = (TextView)findViewById(R.id.textInfo);

        Intent intent = getIntent();


        final String[] organizationURLS  = intent.getStringArrayExtra(MainActivity.EXTRA_MESSAGE);

        title.setText(organizationURLS[0]);
        textHomePage.setText(organizationURLS[1]);
        textInfo.setText(organizationURLS[2]);

        btnWebsite.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(organizationURLS[1]));
                startActivity(intent);
            }
        });

        btnGeneral.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(organizationURLS[2]));
                startActivity(intent);
            }
        });


    }


}