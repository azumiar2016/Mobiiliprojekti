package suomi.fi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class AboutActivity extends AppCompatActivity {
    TextView txtTitle, authorsTitle, authorsText, copyrightTitle, copyrightText;
    Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        txtTitle = (TextView)findViewById(R.id.aboutTitle);
        authorsTitle = (TextView)findViewById(R.id.authorsTitle);
        authorsText = (TextView)findViewById(R.id.authorsText);
        copyrightTitle = (TextView)findViewById(R.id.copyrightText);
        copyrightText = (TextView)findViewById(R.id.copyrightText);
        back = (Button)findViewById(R.id.btnBack);
    }

    protected void goBack(View v){
        Intent intent1 = new Intent(this, MainActivity.class);
        startActivity(intent1);
    }
}
